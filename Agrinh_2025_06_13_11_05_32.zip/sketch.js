let perguntas = [
  {
    texto: "Qual o principal papel do campo na relação com a cidade?",
    opcoes: ["Oferecer mão de obra qualificada", "Produzir alimentos e matérias-primas", "Ser um polo de consumo", "Desenvolver alta tecnologia"],
    correta: 1
  },
  {
    texto: "A urbanização intensifica a conexão campo-cidade, pois:",
    opcoes: ["Diminui produtos agrícolas", "Aumenta a população rural", "Aumenta a demanda por alimentos", "Isola o campo"],
    correta: 2
  },
  {
    texto: "Qual o termo que descreve o movimento de pessoas do campo para a cidade?",
    opcoes: ["Êxodo urbano", "Êxodo rural", "Migração sazonal", "Nomadismo"],
    correta: 1
  },
  {
    texto: "As indústrias nas cidades dependem do campo para:",
    opcoes: ["Vender produtos", "Obter energia", "Matérias-primas", "Atrair turistas"],
    correta: 2
  },
  {
    texto: "A agrotecnologia tem como efeito:",
    opcoes: ["Aumentar mão de obra", "Diminuir produtividade", "Abastecer cidades", "Isolamento rural"],
    correta: 2
  },
  {
    texto: "Principal contribuição da cidade para o campo:",
    opcoes: ["Mão de obra não qualificada", "Serviços e tecnologia", "Grandes lavouras", "Poluição"],
    correta: 1
  },
  {
    texto: "Infraestrutura de transporte serve para:",
    opcoes: ["Impedir mercadorias", "Turismo", "Escoar produção", "Controlar entrada"],
    correta: 2
  },
  {
    texto: "Cinturão verde representa:",
    opcoes: ["Área ambiental urbana", "Agricultura perto da cidade", "Parques urbanos", "Barreira natural"],
    correta: 1
  },
  {
    texto: "A demanda por água urbana pode:",
    opcoes: ["Reduzir irrigação", "Gerar conflitos", "Aumentar água no campo", "Não ter relação"],
    correta: 1
  },
  {
    texto: "Energia de usinas no campo ajuda a cidade ao:",
    opcoes: ["Fornecer mão de obra", "Iluminar cidades", "Aumentar plantio", "Reduzir combustíveis"],
    correta: 1
  },
  {
    texto: "Expansão urbana desordenada causa:",
    opcoes: ["Qualidade rural", "Preservação", "Perda de terras", "Fortalecimento agrícola"],
    correta: 2
  },
  {
    texto: "Turismo rural influencia o campo por:",
    opcoes: ["Reduzir produção", "Demanda por lazer", "Abandono rural", "Menos dinheiro"],
    correta: 1
  },
  {
    texto: "Comunicação no campo é importante para:",
    opcoes: ["Desconectar", "Limitar tecnologia", "Integrar com cidade", "Isolamento social"],
    correta: 2
  },
  {
    texto: "Segurança alimentar significa:",
    opcoes: ["Proteger fronteiras", "Acesso a bons alimentos", "Mercados clandestinos", "Produção para exportação"],
    correta: 1
  },
  {
    texto: "Políticas públicas rurais visam:",
    opcoes: ["Êxodo rural", "Condições e produção", "Só cidade", "Proibir vendas"],
    correta: 1
  },
  {
    texto: "Mão de obra rural busca na cidade:",
    opcoes: ["Trabalho precário", "Empregos e salários", "Contato com natureza", "Menor custo"],
    correta: 1
  },
  {
    texto: "Poluição urbana afeta o campo por:",
    opcoes: ["Não afeta", "Contaminação", "Fertiliza solo", "Mais biodiversidade"],
    correta: 1
  },
  {
    texto: "Intercâmbio cultural aparece em:",
    opcoes: ["Isolamento", "Festas e culinária", "Só cultura urbana", "Assimilação rural"],
    correta: 1
  },
  {
    texto: "Função social da terra busca:",
    opcoes: ["Concentrar terras", "Produção e benefício", "Limitar acesso", "Urbanizar"],
    correta: 1
  },
  {
    texto: "Busca por alimentos locais faz:",
    opcoes: ["Enfraquecer agricultura", "Importação", "Conexão urbana-rural", "Menos preocupação"],
    correta: 2
  }
];

let perguntaAtual = -1;
let respostaSelecionada = -1;
let resultado = "";
let quizFinalizado = false;
let erros = 0;
let acertoEfeito = [];

let particulas = [];

function setup() {
  createCanvas(800, 600);
  textFont('Arial');
  
  // Cria partículas para o efeito inicial e final
  for (let i = 0; i < 100; i++) {
    particulas.push({
      x: random(width),
      y: random(height),
      size: random(2,5),
      vy: random(0.3,1),
      alpha: random(50, 150)
    });
  }
}

function draw() {
  background(40, 70, 120);

  if (perguntaAtual === -1) {
    drawTitleScreen();
    return;
  }

  if (quizFinalizado) {
    drawFinalScreen();
    return;
  }

  drawPergunta();
  updateEfeito();
}

function drawTitleScreen() {
  drawParticulas();
  
  // Título com brilho pulsante
  let brilho = map(sin(frameCount * 0.05), -1, 1, 100, 255);
  textAlign(CENTER, CENTER);
  textSize(42);
  fill(255, 255, 100, brilho);
  stroke(255, 255, 100, brilho);
  strokeWeight(3);
  text("🌿 Quiz: Conexão Campo-Cidade", width / 2, height / 2 - 40);

  noStroke();
  fill(255);
  textSize(22);
  text("Clique para começar", width / 2, height / 2 + 30);
}

function drawFinalScreen() {
  drawParticulas();

  textAlign(CENTER);
  textSize(42);
  let brilho = map(sin(frameCount * 0.05), -1, 1, 100, 255);
  fill(255, 255, 100, brilho);
  stroke(255, 255, 100, brilho);
  strokeWeight(3);
  text("🎉 Quiz finalizado!", width / 2, height / 2 - 80);

  noStroke();
  fill(255);
  textSize(24);
  text("Você errou " + erros + " de " + perguntas.length + " perguntas.", width / 2, height / 2 - 30);
  textSize(20);
  text("Obrigado por participar!", width / 2, height / 2 + 20);
}

function drawPergunta() {
  textSize(20);
  textAlign(LEFT, TOP);
  fill(255);
  rect(40, 30, 720, 100, 10);
  fill(0);
  text(perguntas[perguntaAtual].texto, 50, 40, 700, 100);

  textSize(16);
  for (let i = 0; i < 4; i++) {
    let y = 160 + i * 60;
    fill(255);
    rect(60, y, 680, 50, 10);
    fill(0);
    textAlign(LEFT, CENTER);
    text(perguntas[perguntaAtual].opcoes[i], 80, y + 25);
  }

  if (resultado !== "") {
    textAlign(CENTER);
    fill(resultado === "Correta!" ? 'gold' : 'red');
    textSize(24);
    text(resultado, width / 2, height - 100);
  }

  drawEfeito();
}

function mousePressed() {
  if (perguntaAtual === -1) {
    perguntaAtual = 0;
    return;
  }

  if (quizFinalizado) return;

  for (let i = 0; i < 4; i++) {
    let y = 160 + i * 60;
    if (mouseX > 60 && mouseX < 740 && mouseY > y && mouseY < y + 50) {
      respostaSelecionada = i;
      if (i === perguntas[perguntaAtual].correta) {
        resultado = "Correta!";
        for (let j = 0; j < 20; j++) {
          acertoEfeito.push({
            x: width / 2,
            y: height - 100,
            vx: random(-2, 2),
            vy: random(-3, -1),
            alpha: 255
          });
        }
      } else {
        resultado = "Incorreta.";
        erros++;
      }

      setTimeout(() => {
        if (perguntaAtual < perguntas.length - 1) {
          perguntaAtual++;
          resultado = "";
        } else {
          quizFinalizado = true;
        }
      }, 1200);
    }
  }
}

function drawEfeito() {
  for (let p of acertoEfeito) {
    fill(255, 215, 0, p.alpha);
    noStroke();
    ellipse(p.x, p.y, 8, 8);
  }
}

function updateEfeito() {
  for (let p of acertoEfeito) {
    p.x += p.vx;
    p.y += p.vy;
    p.alpha -= 5;
  }
  acertoEfeito = acertoEfeito.filter(p => p.alpha > 0);
}

function drawParticulas() {
  for (let p of particulas) {
    noStroke();
    fill(255, 255, 200, p.alpha);
    ellipse(p.x, p.y, p.size);
    p.y -= p.vy;
    if (p.y < 0) {
      p.y = height;
      p.x = random(width);
      p.alpha = random(50, 150);
      p.size = random(2,5);
      p.vy = random(0.3,1);
    }
  }
}
